package timbon;

import java.time.Duration;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SwagLabsTestDemo {
    static ChromeDriver driver;
    static WebDriverWait wait;
    final String BASE_URL = "https://www.saucedemo.com/";
    final String VALID_USERNAME = "standard_user";
    final String VALID_PASSWORD = "secret_sauce";
    
    @BeforeEach
    void setUp() {
        driver = new ChromeDriver();
        wait  = new WebDriverWait(driver, Duration.ofSeconds(60));
        driver.manage().window().maximize();
        driver.get(BASE_URL);
    }
    
    @AfterEach
    void tearDown() {
        if(driver != null) {
            driver.quit();
        }
    }
    
    @DisplayName("Login successfully")
    @Test
    void testLoginSuccess() throws InterruptedException {
        //*[@id="user-name"]
        WebElement usernameField = driver.findElement(By.id("user-name"));
        usernameField.sendKeys(VALID_USERNAME);
        Thread.sleep(1000);
        
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys(VALID_PASSWORD);
        Thread.sleep(1000);
        
        WebElement loginButton = driver.findElement(By.id("login-button"));
        loginButton.click();
        Thread.sleep(1000);
        
        
        String expectedPageURL = "https://www.saucedemo.com/inventory.html";
        String actualPageURL = driver.getCurrentUrl();
        Assertions.assertEquals(expectedPageURL, actualPageURL);
        Thread.sleep(3000);
    }
    
    @DisplayName("Login with empty fields")
    @Test
    void testLoginEmptyFields() throws InterruptedException {
        //*[@id="user-name"]
        WebElement usernameField = driver.findElement(By.id("user-name"));
        usernameField.sendKeys("");
        Thread.sleep(1000);
        
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("");
        Thread.sleep(1000);
        
        WebElement loginButton = driver.findElement(By.id("login-button"));
        loginButton.click();
        Thread.sleep(1000);
        
        WebElement errorMessageField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[@data-test='error']")));
        String expectedErrorMessage = "Epic sadface: Username is required";
        String actualErrorMessage = errorMessageField.getText();
        Assertions.assertEquals(expectedErrorMessage, actualErrorMessage);
    }
    
    
}
