import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class QARegistrationTest {
    private WebDriver driver;

    @BeforeEach
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @Test
    public void testDemoQARegistration() {
        driver.get("https://demoqa.com/automation-practice-form");
        JavascriptExecutor js = (JavascriptExecutor) driver;

        // 1. Zoom out slightly to ensure elements aren't hidden behind the footer
        js.executeScript("document.body.style.zoom='75%'");

        // 2. Remove Ads and Footer to prevent interception
        js.executeScript(
                "var fb=document.getElementById('fixedban'); if(fb){fb.style.display='none';}" +
                        "var ft=document.querySelector('footer'); if(ft){ft.style.display='none';}"
        );

        // Fill Basic Details
        driver.findElement(By.id("firstName")).sendKeys("Nguyen");
        driver.findElement(By.id("lastName")).sendKeys("Van A");
        driver.findElement(By.id("userEmail")).sendKeys("nguyenvana@example.com");

        // Gender (Use JS Click for reliability)
        WebElement genderMale = driver.findElement(By.id("gender-radio-1"));
        js.executeScript("arguments[0].click();", genderMale);

        driver.findElement(By.id("userNumber")).sendKeys("0123456789");

        // Date of Birth: 15 March 2000
        driver.findElement(By.id("dateOfBirthInput")).click();

        WebElement monthDropdown = driver.findElement(By.className("react-datepicker__month-select"));
        new Select(monthDropdown).selectByVisibleText("March");

        WebElement yearDropdown = driver.findElement(By.className("react-datepicker__year-select"));
        new Select(yearDropdown).selectByVisibleText("2000");

        driver.findElement(By.xpath("//div[contains(@class, 'react-datepicker__day') and text()='15']")).click();

        // Hobbies: Sports
        WebElement sportsCheckbox = driver.findElement(By.id("hobbies-checkbox-1"));
        js.executeScript("arguments[0].click();", sportsCheckbox);

        driver.findElement(By.id("currentAddress")).sendKeys("123 Đường ABC, Hà Nội");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // State Selection
        WebElement stateContainer = driver.findElement(By.id("state"));
        js.executeScript("arguments[0].scrollIntoView({block:'center'});", stateContainer);
        stateContainer.click();

        WebElement stateInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("react-select-3-input")));
        stateInput.sendKeys("NCR");
        stateInput.sendKeys(Keys.TAB);

        // City Selection
        WebElement cityContainer = driver.findElement(By.id("city"));
        cityContainer.click();

        WebElement cityInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("react-select-4-input")));
        cityInput.sendKeys("Delhi");
        cityInput.sendKeys(Keys.TAB);

        // Submit Form
        WebElement submitBtn = driver.findElement(By.id("submit"));
        js.executeScript("arguments[0].scrollIntoView({block: 'center'});", submitBtn);

        // Use JS click to ensure it works even if ad remnants overlap
        js.executeScript("arguments[0].click();", submitBtn);

        // ASSERTION
        // Wait for the modal title (Note: ID is 'example-modal-sizes-title-lg')
        WebElement successModalTitle = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.id("example-modal-sizes-title-lg"))
        );

        assertTrue(successModalTitle.isDisplayed(), "Modal không hiển thị!");
        assertTrue(successModalTitle.getText().contains("Thanks for submitting the form"), "Tiêu đề modal không đúng!");
    }

    @AfterEach
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}