import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class QALoginTest {
    private WebDriver driver;

    @BeforeEach
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @AfterEach
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void testLoginSuccess() throws Exception {
        String username = "user_" + UUID.randomUUID().toString().replace("-", "").substring(0, 8);
        String password = "Abcdefg1!"; // meets DemoQA password policy

        ApiClientTestUtil.createDemoQaUser(username, password);

        driver.get("https://demoqa.com/login");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("userName"))).sendKeys(username);
        driver.findElement(By.id("password")).sendKeys(password);

        WebElement loginBtn = driver.findElement(By.id("login"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", loginBtn);
        // Hide potential sticky overlays similar to other pages
        ((JavascriptExecutor) driver).executeScript(
                "var fb=document.getElementById('fixedban'); if(fb){fb.style.display='none';}"
                        + "var ft=document.querySelector('footer'); if(ft){ft.style.display='none';}");

        wait.until(ExpectedConditions.elementToBeClickable(loginBtn)).click();

        // Expect to land on profile page and see username value
        wait.until(ExpectedConditions.urlContains("profile"));
        WebElement userNameValue = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.id("userName-value"))
        );
        assertEquals(username, userNameValue.getText());
    }

    @Test
    public void testLoginFailure() {
        String username = "nonexistent_" + UUID.randomUUID().toString().replace("-", "").substring(0, 8);
        String password = "WrongPass1!";

        driver.get("https://demoqa.com/login");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("userName"))).sendKeys(username);
        driver.findElement(By.id("password")).sendKeys(password);

        WebElement loginBtn = driver.findElement(By.id("login"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", loginBtn);
        ((JavascriptExecutor) driver).executeScript(
                "var fb=document.getElementById('fixedban'); if(fb){fb.style.display='none';}"
                        + "var ft=document.querySelector('footer'); if(ft){ft.style.display='none';}");

        wait.until(ExpectedConditions.elementToBeClickable(loginBtn)).click();

        // Error message is shown in element with id 'name'
        WebElement error = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.id("name"))
        );
        assertTrue(error.getText().toLowerCase().contains("invalid"));
    }
}
