import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class GoogleSearchTest {
    private WebDriver driver;

    @BeforeEach
    public void setUp() {
//        System.setProperty("webdriver.chrome.driver", "đường_dẫn_tới_chromedriver/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();

    }


    @Test
    public void testGoogleSearch() {
        driver.get("https://www.google.com");
        WebElement searchBox = driver.findElement(By.name("q"));
        searchBox.sendKeys("Selenium automation testing");
        searchBox.submit();

        String pageSource = driver.getPageSource();
        assertTrue(pageSource.contains("Selenium"), "Kết quả không chứa từ 'Selenium'");
    }


    @AfterEach
    public void tearDown() {
        if (driver != null) {
            driver.quit();

        }

    }

}
