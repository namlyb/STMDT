import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;

/**
 * Minimal HTTP helper for DemoQA Book Store API used by tests.
 */
public class ApiClientTestUtil {
    private static final String BASE_URL = "https://demoqa.com";

    public static void createDemoQaUser(String userName, String password) throws IOException, InterruptedException {
        HttpClient client = HttpClient.newHttpClient();
        String payload = "{\"userName\":\"" + escape(userName) + "\",\"password\":\"" + escape(password) + "\"}";
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/Account/v1/User"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(payload, StandardCharsets.UTF_8))
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        int code = response.statusCode();
        if (code != 201 && code != 406) { // 201 = created, 406 = already exists
            throw new IOException("Failed to create user. HTTP " + code + ": " + response.body());
        }
    }

    private static String escape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
